
import React from 'react';
import { Entity } from '../types';
import { ENTITY_COLORS } from '../constants.tsx';

interface NERHighlighterProps {
  text: string;
  entities: Entity[];
}

export const NERHighlighter: React.FC<NERHighlighterProps> = ({ text, entities }) => {
  const sortedEntities = [...entities].sort((a, b) => a.start - b.start);
  
  const segments: React.ReactNode[] = [];
  let lastIndex = 0;

  sortedEntities.forEach((entity, index) => {
    if (entity.start > lastIndex) {
      segments.push(<span key={`text-${index}`} className="text-slate-700">{text.substring(lastIndex, entity.start)}</span>);
    }

    const colorClass = ENTITY_COLORS[entity.label.toUpperCase()] || 'bg-slate-200 text-slate-700 border-slate-300';
    segments.push(
      <span
        key={`entity-${index}`}
        className={`inline-flex items-baseline px-2 py-0.5 rounded-lg border font-bold mx-0.5 shadow-sm transform hover:scale-105 transition-transform duration-200 cursor-default ${colorClass}`}
        title={entity.label}
      >
        {entity.text}
        <span className="text-[9px] ml-1.5 opacity-60 uppercase font-black tracking-tighter">
          {entity.label}
        </span>
      </span>
    );

    lastIndex = entity.end;
  });

  if (lastIndex < text.length) {
    segments.push(<span key="text-end" className="text-slate-700">{text.substring(lastIndex)}</span>);
  }

  return (
    <div className="leading-[2.5] text-xl md:text-2xl whitespace-pre-wrap font-medium">
      {segments.length > 0 ? segments : text}
    </div>
  );
};
