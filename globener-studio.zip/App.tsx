
import React, { useState, useMemo } from 'react';
import { SUPPORTED_LANGUAGES } from './constants.tsx';
import { LanguageConfig, NERResult } from './types';
import { performNER } from './services/geminiService';
import { NERHighlighter } from './components/NERHighlighter';

const App: React.FC = () => {
  const [selectedLang, setSelectedLang] = useState<LanguageConfig>(SUPPORTED_LANGUAGES[0]);
  const [inputText, setInputText] = useState(SUPPORTED_LANGUAGES[0].sampleText);
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<NERResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLanguages = useMemo(() => {
    return SUPPORTED_LANGUAGES.filter(lang => 
      lang.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm]);

  const handleLangChange = (lang: LanguageConfig) => {
    setSelectedLang(lang);
    setInputText(lang.sampleText);
    setResult(null);
    setError(null);
  };

  const handleAnalyze = async () => {
    if (!inputText.trim()) return;
    setIsLoading(true);
    setError(null);
    try {
      const data = await performNER(inputText, selectedLang.name);
      setResult(data);
    } catch (err) {
      console.error(err);
      setError("Failed to analyze text. Please check your connection or API key.");
    } finally {
      setIsLoading(false);
    }
  };

  // Extract base color for the input area background
  const getThemeBaseColor = (gradient: string) => {
    if (gradient.includes('blue')) return 'bg-blue-50/50';
    if (gradient.includes('orange')) return 'bg-orange-50/50';
    if (gradient.includes('emerald')) return 'bg-emerald-50/50';
    if (gradient.includes('yellow')) return 'bg-yellow-50/50';
    if (gradient.includes('pink')) return 'bg-pink-50/50';
    if (gradient.includes('teal')) return 'bg-teal-50/50';
    if (gradient.includes('amber')) return 'bg-amber-50/50';
    if (gradient.includes('red')) return 'bg-red-50/50';
    return 'bg-indigo-50/50';
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Dynamic Background Blob */}
      <div className={`fixed inset-0 -z-10 opacity-10 blur-[120px] transition-colors duration-1000 bg-gradient-to-br ${selectedLang.gradient}`}></div>

      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Modern Creative Header */}
        <header className="mb-16 flex flex-col items-center">
          <div className={`w-20 h-20 rounded-3xl bg-gradient-to-br ${selectedLang.gradient} shadow-2xl flex items-center justify-center mb-6 transform rotate-3 hover:rotate-0 transition-transform duration-500`}>
            <i className="fas fa-microchip text-3xl text-white"></i>
          </div>
          <h1 className="text-6xl font-black text-slate-900 tracking-tight text-center">
            Globe<span className={`text-transparent bg-clip-text bg-gradient-to-r ${selectedLang.gradient}`}>NER</span>
          </h1>
          <p className="text-slate-500 mt-4 text-lg font-medium text-center max-w-xl">
            Intelligent entity recognition for <span className="text-slate-800 font-bold">all world languages</span>. Just choose your language and start exploring.
          </p>
        </header>

        <div className="grid lg:grid-cols-12 gap-10">
          {/* Sidebar: Searchable Language List */}
          <aside className="lg:col-span-3 space-y-6">
            <div className="bg-white/70 backdrop-blur-md rounded-3xl p-6 border border-slate-200 shadow-sm">
              <div className="relative mb-4">
                <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                <input 
                  type="text" 
                  placeholder="Find language..." 
                  className="w-full pl-10 pr-4 py-3 bg-slate-100 rounded-2xl border-none focus:ring-2 focus:ring-slate-300 transition-all text-sm font-semibold"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="space-y-1 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
                {filteredLanguages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => handleLangChange(lang)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-all duration-200 ${
                      selectedLang.code === lang.code
                        ? `bg-gradient-to-r ${lang.gradient} text-white shadow-lg shadow-indigo-100`
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <span className={`w-2 h-2 rounded-full ${selectedLang.code === lang.code ? 'bg-white' : 'bg-slate-300 opacity-50'}`}></span>
                    <span className="font-bold text-sm tracking-wide">{lang.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </aside>

          {/* Main Area: Input and Results */}
          <div className="lg:col-span-9 space-y-8">
            <div className="grid md:grid-cols-1 gap-8">
              {/* Creative Input Area */}
              <section className="relative group">
                <div className={`absolute -inset-1 bg-gradient-to-r ${selectedLang.gradient} rounded-[2.5rem] blur opacity-5 group-hover:opacity-10 transition duration-500`}></div>
                <div className={`relative ${getThemeBaseColor(selectedLang.gradient)} rounded-[2rem] border-2 border-white/50 shadow-2xl overflow-hidden backdrop-blur-sm`}>
                  <div className="p-8">
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-4">
                        <div className={`p-3 rounded-2xl bg-gradient-to-br ${selectedLang.gradient} text-white shadow-lg`}>
                          <i className="fas fa-keyboard"></i>
                        </div>
                        <div>
                          <h2 className="text-xl font-black text-slate-800 tracking-tight">{selectedLang.name} Input</h2>
                          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Type or paste text below</p>
                        </div>
                      </div>
                      <div className="hidden sm:block">
                        <span className="text-xs font-black text-slate-400 bg-white/50 px-4 py-2 rounded-full border border-white">
                          DETECTING: {selectedLang.name.toUpperCase()}
                        </span>
                      </div>
                    </div>

                    <textarea
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      className="w-full h-48 bg-transparent border-none focus:ring-0 text-2xl font-bold text-slate-800 placeholder-slate-300 resize-none leading-relaxed"
                      placeholder={`Write something interesting in ${selectedLang.name}...`}
                    />

                    <div className="mt-8 flex items-center justify-between">
                      <div className="flex items-center gap-3 text-slate-400">
                        <div className="flex -space-x-2">
                          {[1,2,3].map(i => <div key={i} className="w-6 h-6 rounded-full bg-slate-200 border-2 border-white"></div>)}
                        </div>
                        <span className="text-xs font-bold uppercase tracking-widest">{inputText.length} characters</span>
                      </div>
                      <button
                        onClick={handleAnalyze}
                        disabled={isLoading || !inputText.trim()}
                        className={`group relative px-10 py-4 rounded-2xl font-black text-white transition-all transform hover:scale-105 active:scale-95 disabled:opacity-50 shadow-xl`}
                      >
                        <div className={`absolute inset-0 bg-gradient-to-r ${selectedLang.gradient} rounded-2xl`}></div>
                        <span className="relative z-10 flex items-center gap-3 tracking-widest text-sm uppercase">
                          {isLoading ? (
                            <i className="fas fa-atom fa-spin"></i>
                          ) : (
                            <i className="fas fa-bolt-lightning"></i>
                          )}
                          {isLoading ? "Analyzing..." : "Process Text"}
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </section>

              {/* Results Display */}
              <section className="min-h-[300px]">
                {error && (
                  <div className="bg-rose-50 border-2 border-rose-100 p-6 rounded-[2rem] flex items-center gap-6 animate-shake">
                    <div className="w-14 h-14 bg-rose-100 rounded-2xl flex items-center justify-center shrink-0">
                      <i className="fas fa-triangle-exclamation text-rose-500 text-2xl"></i>
                    </div>
                    <div>
                      <h4 className="text-rose-900 font-black text-lg">Analysis Error</h4>
                      <p className="text-rose-600 font-medium">{error}</p>
                    </div>
                  </div>
                )}

                {!result && !isLoading && !error && (
                  <div className="h-full flex flex-col items-center justify-center p-12 border-4 border-dashed border-slate-100 rounded-[2rem] bg-slate-50/30 text-center">
                    <div className="w-20 h-20 bg-white rounded-3xl shadow-sm flex items-center justify-center mb-6 text-slate-200">
                      <i className="fas fa-layer-group text-4xl"></i>
                    </div>
                    <h3 className="text-2xl font-black text-slate-300">Awaiting Data</h3>
                    <p className="text-slate-300 font-medium max-w-xs mx-auto">Results will populate here automatically after processing.</p>
                  </div>
                )}

                {isLoading && (
                  <div className="h-full flex flex-col items-center justify-center p-12 bg-white border border-slate-100 rounded-[2rem] shadow-sm text-center">
                    <div className="relative">
                      <div className={`w-24 h-24 border-8 border-slate-50 border-t-indigo-500 rounded-full animate-spin`}></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <i className={`fas fa-wand-sparkles text-2xl animate-pulse text-indigo-300`}></i>
                      </div>
                    </div>
                    <h3 className="text-2xl font-black text-slate-800 mt-10">AI at Work</h3>
                    <p className="text-slate-400 font-bold uppercase tracking-[0.2em] text-xs mt-2">Named Entity Recognition</p>
                  </div>
                )}

                {result && !isLoading && !error && (
                  <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-500">
                    <div className="bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-2xl shadow-slate-200/50">
                      <div className="flex items-center gap-3 mb-10">
                        <div className="w-1.5 h-6 bg-indigo-500 rounded-full"></div>
                        <h3 className="text-2xl font-black text-slate-800 tracking-tight">Interactive Highlight</h3>
                      </div>
                      <div className="p-8 bg-slate-50/50 rounded-3xl border border-slate-100/50">
                        <NERHighlighter text={result.originalText} entities={result.entities} />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      {result.entities.length > 0 ? (
                        result.entities.map((ent, idx) => (
                          <div 
                            key={idx} 
                            className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all duration-300 group"
                          >
                            <div className="flex items-center justify-between mb-4">
                              <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                                ent.label.toUpperCase().includes('PERSON') ? 'bg-blue-50 text-blue-600' :
                                ent.label.toUpperCase().includes('LOC') ? 'bg-emerald-50 text-emerald-600' :
                                ent.label.toUpperCase().includes('ORG') ? 'bg-indigo-50 text-indigo-600' :
                                'bg-amber-50 text-amber-600'
                              }`}>
                                {ent.label}
                              </span>
                              <i className="fas fa-fingerprint text-slate-100 group-hover:text-indigo-100 transition-colors"></i>
                            </div>
                            <p className="text-xl font-black text-slate-800 leading-tight">{ent.text}</p>
                          </div>
                        ))
                      ) : (
                        <div className="col-span-full bg-slate-50 p-12 rounded-[2rem] text-center border border-slate-100">
                          <p className="text-slate-400 font-black italic">No entities detected in this passage.</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </section>
            </div>
          </div>
        </div>
      </div>

      <footer className="mt-20 py-12 bg-slate-50 border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-3">
            <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${selectedLang.gradient}`}></div>
            <span className="text-slate-900 font-black tracking-tight">GlobeNER Studio</span>
          </div>
          <p className="text-slate-400 text-sm font-bold uppercase tracking-widest">
            &copy; 2025 AI for the World
          </p>
          <div className="flex gap-6">
            <i className="fab fa-github text-xl text-slate-300 hover:text-slate-900 transition-colors cursor-pointer"></i>
            <i className="fab fa-twitter text-xl text-slate-300 hover:text-slate-900 transition-colors cursor-pointer"></i>
            <i className="fas fa-envelope text-xl text-slate-300 hover:text-slate-900 transition-colors cursor-pointer"></i>
          </div>
        </div>
      </footer>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #e2e8f0;
          border-radius: 10px;
        }
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-4px); }
          75% { transform: translateX(4px); }
        }
        .animate-shake {
          animation: shake 0.4s ease-in-out infinite alternate;
        }
      `}</style>
    </div>
  );
};

export default App;
