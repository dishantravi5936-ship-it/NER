
export interface Entity {
  text: string;
  label: string; // PERSON, LOC, ORG, DATE, etc.
  start: number;
  end: number;
}

export interface NERResult {
  originalText: string;
  entities: Entity[];
  explanation?: string;
}

export interface LanguageConfig {
  code: string;
  name: string;
  sampleText: string;
  gradient: string;
}
