
import { GoogleGenAI, Type } from "@google/genai";
import { NERResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const performNER = async (text: string, language: string): Promise<NERResult> => {
  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: `Perform Named Entity Recognition (NER) on the following ${language} text. 
    Identify entities like PERSON, LOCATION (or LOC), ORGANIZATION (or ORG), and DATE.
    Return only a JSON object containing the entities with their exact text, character start and end indices, and label.
    
    Text: "${text}"`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          entities: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                text: { type: Type.STRING },
                label: { type: Type.STRING },
                start: { type: Type.NUMBER },
                end: { type: Type.NUMBER }
              },
              required: ["text", "label", "start", "end"]
            }
          }
        },
        required: ["entities"]
      }
    }
  });

  const result = JSON.parse(response.text || '{"entities": []}');
  return {
    originalText: text,
    entities: result.entities
  };
};
