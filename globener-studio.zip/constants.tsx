
import { LanguageConfig } from './types';

export const SUPPORTED_LANGUAGES: LanguageConfig[] = [
  {
    code: 'en',
    name: 'English',
    sampleText: "Sundar Pichai is the CEO of Google and Alphabet, currently based in Mountain View, California.",
    gradient: 'from-blue-500 to-indigo-600'
  },
  {
    code: 'hi',
    name: 'Hindi',
    sampleText: "नरेंद्र मोदी भारत के प्रधानमंत्री हैं। उनका जन्म गुजरात के वडनगर में हुआ था और अब वे नई दिल्ली में रहते हैं।",
    gradient: 'from-orange-500 to-red-600'
  },
  {
    code: 'bn',
    name: 'Bengali',
    sampleText: "রবীন্দ্রনাথ ঠাকুর ছিলেন একজন বিশ্ববিখ্যাত কবি। তিনি কলকাতার জোড়াসাঁকোতে জন্মগ্রহণ করেন।",
    gradient: 'from-emerald-500 to-teal-700'
  },
  {
    code: 'mr',
    name: 'Marathi',
    sampleText: "छत्रपती शिवाजी महाराज हे मराठा साम्राज्याचे संस्थापक होते. रायगड ही त्यांची राजधानी होती.",
    gradient: 'from-orange-400 to-amber-600'
  },
  {
    code: 'kn',
    name: 'Kannada',
    sampleText: "ಸಿದ್ಧರಾಮಯ್ಯನವರು ಕರ್ನಾಟಕದ ಮುಖ್ಯಮಂತ್ರಿಗಳು. ಬೆಂಗಳೂರಿನ ವಿಧಾನ ಸೌಧದಲ್ಲಿ ಅವರ ಕಚೇರಿ ಇದೆ.",
    gradient: 'from-yellow-400 to-orange-500'
  },
  {
    code: 'te',
    name: 'Telugu',
    sampleText: "నారా చంద్రబాబు నాయుడు ఆంధ్రప్రదేశ్ ముఖ్యమంత్రి. అమరావతి రాష్ట్ర రాజధానిగా అభివృద్ధి చెందుతోంది.",
    gradient: 'from-green-500 to-emerald-600'
  },
  {
    code: 'ta',
    name: 'Tamil',
    sampleText: "எம். கே. ஸ்டாலின் தமிழ்நாட்டின் முதலமைச்சர். சென்னை புனித ஜார்ஜ் கோட்டையில் தமிழக அரசு இயங்குகிறது.",
    gradient: 'from-pink-500 to-rose-600'
  },
  {
    code: 'ml',
    name: 'Malayalam',
    sampleText: "പിണറായി വിജയൻ കേരളത്തിന്റെ മുഖ്യമന്ത്രിയാണ്. തിരുവനന്തപുരത്തെ സെക്രട്ടേറിയറ്റിലാണ് അദ്ദേഹത്തിന്റെ ഓഫീസ്.",
    gradient: 'from-teal-500 to-cyan-600'
  },
  {
    code: 'gu',
    name: 'Gujarati',
    sampleText: "મહાત્મા ગાંધીનો જન્મ પોરબંદરમાં થયો હતો. તેમને ભારતના રાષ્ટ્રપિતા માનવામાં આવે છે.",
    gradient: 'from-amber-400 to-yellow-600'
  },
  {
    code: 'pa',
    name: 'Punjabi',
    sampleText: "ਅੰਮ੍ਰਿਤਸਰ ਦਾ ਹਰਿਮੰਦਰ ਸਾਹਿਬ ਸਿੱਖ ਧਰਮ ਦਾ ਸਭ ਤੋਂ ਪਵਿੱਤਰ ਅਸਥਾਨ ਹੈ।",
    gradient: 'from-red-400 to-orange-600'
  },
  {
    code: 'es',
    name: 'Spanish',
    sampleText: "Miguel de Cervantes escribió Don Quijote de la Mancha en Madrid, España.",
    gradient: 'from-red-500 to-yellow-500'
  },
  {
    code: 'fr',
    name: 'French',
    sampleText: "Emmanuel Macron est le président de la France. Il travaille au Palais de l'Élysée à Paris.",
    gradient: 'from-blue-700 to-red-700'
  }
];

export const ENTITY_COLORS: Record<string, string> = {
  PERSON: 'bg-blue-100/80 text-blue-900 border-blue-200',
  LOC: 'bg-emerald-100/80 text-emerald-900 border-emerald-200',
  LOCATION: 'bg-emerald-100/80 text-emerald-900 border-emerald-200',
  ORG: 'bg-indigo-100/80 text-indigo-900 border-indigo-200',
  ORGANIZATION: 'bg-indigo-100/80 text-indigo-900 border-indigo-200',
  DATE: 'bg-amber-100/80 text-amber-900 border-amber-200',
  GPE: 'bg-teal-100/80 text-teal-900 border-teal-200',
  PRODUCT: 'bg-rose-100/80 text-rose-900 border-rose-200',
  EVENT: 'bg-violet-100/80 text-violet-900 border-violet-200',
};
